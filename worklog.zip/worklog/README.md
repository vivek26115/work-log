# 📋 Office Work Log

A clean, dark-themed daily work tracker for logging what you did each hour from **9 AM to 4:30 PM**.

Built for Web Developer Trainers (or anyone with a structured office day).

## ✨ Features

- 8 time slots: 9:00 AM → 4:30 PM
- Activity tags: Teaching, Coding, Review, Meeting, Planning, Demo, Break, Admin
- Notes per slot
- Progress ring & live stats
- Date navigation (prev/next day)
- View daily summary in a modal
- Copy full report to clipboard
- All data saved in **localStorage** (no backend needed)
- Works fully offline

## 🚀 How to Host on GitHub Pages

1. Create a new GitHub repository (e.g. `work-log`)
2. Upload these 3 files:
   - `index.html`
   - `style.css`
   - `app.js`
3. Go to **Settings → Pages**
4. Under "Branch", select `main` → `/ (root)` → **Save**
5. Your site will be live at: `https://yourusername.github.io/work-log`

## 📁 File Structure

```
work-log/
├── index.html   ← Main page
├── style.css    ← All styles
├── app.js       ← All logic
└── README.md    ← This file
```

## 💡 Usage

- Click any time slot to expand and log your work
- Select tags + add a note → click **Save**
- Use **View Summary** to see your day at a glance
- Use **Copy Report** to share your work log (WhatsApp, email, etc.)
- Navigate between days using ← → arrows

## 🔒 Privacy

All data is stored locally in your browser's `localStorage`.  
Nothing is sent to any server. Your data stays on your device.
