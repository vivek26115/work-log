// ── DATA ──────────────────────────────────────────────────────────────────
const SLOTS = [
  { id: 's1', time: '9:00 – 10:00 AM',       hrs: 1   },
  { id: 's2', time: '10:00 – 11:00 AM',      hrs: 1   },
  { id: 's3', time: '11:00 AM – 12:00 PM',   hrs: 1   },
  { id: 's4', time: '12:00 – 1:00 PM',       hrs: 1, lunch: true },
  { id: 's5', time: '1:00 – 2:00 PM',        hrs: 1   },
  { id: 's6', time: '2:00 – 3:00 PM',        hrs: 1   },
  { id: 's7', time: '3:00 – 4:00 PM',        hrs: 1   },
  { id: 's8', time: '4:00 – 4:30 PM',        hrs: 0.5 },
];

const TAGS = ['Teaching', 'Coding', 'Review', 'Meeting', 'Planning', 'Demo', 'Break', 'Admin'];

const DAYS = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];

let currentDate = '';
let dayData = {};  // { slotId: { text, tags } }

// ── HELPERS ───────────────────────────────────────────────────────────────
function todayStr() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function storageKey(date) {
  return 'worklog_' + date;
}

function loadData(date) {
  try {
    const raw = localStorage.getItem(storageKey(date));
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function saveData() {
  localStorage.setItem(storageKey(currentDate), JSON.stringify(dayData));
}

function fmtDate(str) {
  const d = new Date(str + 'T00:00:00');
  return d.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}

function dayOfWeek(str) {
  return DAYS[new Date(str + 'T00:00:00').getDay()];
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2500);
}

// ── RENDER SLOTS ──────────────────────────────────────────────────────────
function renderSlots() {
  const container = document.getElementById('slots-container');
  container.innerHTML = '';

  SLOTS.forEach(slot => {
    const entry = dayData[slot.id] || { text: '', tags: [] };
    const hasEntry = entry.text.trim() || entry.tags.length > 0;

    const slotEl = document.createElement('div');
    slotEl.className = 'slot' + (hasEntry ? ' has-entry' : '') + (slot.lunch ? ' is-lunch' : '');
    slotEl.id = 'slot-' + slot.id;

    // Preview text
    let preview = 'Tap to log...';
    if (hasEntry) {
      const parts = [];
      if (entry.tags.length) parts.push(entry.tags.join(', '));
      if (entry.text.trim()) parts.push(entry.text.trim().slice(0, 50));
      preview = parts.join(' · ');
    }

    slotEl.innerHTML = `
      <div class="slot-header" data-slot="${slot.id}">
        <span class="slot-indicator"></span>
        <span class="slot-time">${slot.time}${slot.lunch ? ' 🍽' : ''}</span>
        <span class="slot-preview ${hasEntry ? 'filled' : ''}">${preview}</span>
        <span class="slot-chevron">▾</span>
      </div>
      <div class="slot-body">
        <div class="tag-section">
          <span class="tag-section-label">Activity tags</span>
          <div class="tags-row">
            ${TAGS.map(tag => `
              <button class="tag-btn ${entry.tags.includes(tag) ? 'active' : ''}" data-tag="${tag}" data-slot="${slot.id}">
                ${tag}
              </button>
            `).join('')}
          </div>
        </div>
        <textarea class="slot-textarea" id="txt-${slot.id}" placeholder="What did you work on during this slot?">${entry.text || ''}</textarea>
        <div class="slot-actions">
          <button class="btn-cancel" data-slot="${slot.id}">Cancel</button>
          <button class="btn-save" data-slot="${slot.id}">✓ Save</button>
        </div>
      </div>
    `;

    container.appendChild(slotEl);
  });

  // attach events after rendering
  attachSlotEvents();
}

function attachSlotEvents() {
  // Toggle open/close on header click
  document.querySelectorAll('.slot-header').forEach(header => {
    header.addEventListener('click', function () {
      const slotId = this.getAttribute('data-slot');
      const slotEl = document.getElementById('slot-' + slotId);
      const isOpen = slotEl.classList.contains('open');

      // close all
      document.querySelectorAll('.slot').forEach(s => s.classList.remove('open'));

      if (!isOpen) {
        slotEl.classList.add('open');
        // focus textarea
        const ta = document.getElementById('txt-' + slotId);
        if (ta) setTimeout(() => ta.focus(), 50);
      }
    });
  });

  // Tag toggle
  document.querySelectorAll('.tag-btn').forEach(btn => {
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      const slotId = this.getAttribute('data-slot');
      const tag = this.getAttribute('data-tag');
      if (!dayData[slotId]) dayData[slotId] = { text: '', tags: [] };
      const idx = dayData[slotId].tags.indexOf(tag);
      if (idx > -1) {
        dayData[slotId].tags.splice(idx, 1);
        this.classList.remove('active');
      } else {
        dayData[slotId].tags.push(tag);
        this.classList.add('active');
      }
    });
  });

  // Save button
  document.querySelectorAll('.btn-save').forEach(btn => {
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      const slotId = this.getAttribute('data-slot');
      const ta = document.getElementById('txt-' + slotId);
      if (!dayData[slotId]) dayData[slotId] = { text: '', tags: [] };
      dayData[slotId].text = ta.value.trim();
      saveData();
      renderSlots();
      updateStats();
      showToast('✓ Saved!');
    });
  });

  // Cancel button
  document.querySelectorAll('.btn-cancel').forEach(btn => {
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      const slotId = this.getAttribute('data-slot');
      const slotEl = document.getElementById('slot-' + slotId);
      slotEl.classList.remove('open');
    });
  });
}

// ── STATS ─────────────────────────────────────────────────────────────────
function updateStats() {
  let filled = 0;
  let hrs = 0;
  const tagCount = {};

  SLOTS.forEach(slot => {
    const entry = dayData[slot.id];
    if (entry && (entry.text.trim() || entry.tags.length > 0)) {
      filled++;
      hrs += slot.hrs;
      (entry.tags || []).forEach(t => tagCount[t] = (tagCount[t] || 0) + 1);
    }
  });

  document.getElementById('stat-filled').textContent = filled;
  document.getElementById('stat-hours').textContent = hrs % 1 === 0 ? hrs : hrs.toFixed(1);

  const topTag = Object.entries(tagCount).sort((a, b) => b[1] - a[1])[0];
  document.getElementById('stat-tag').textContent = topTag ? topTag[0] : '—';
  document.getElementById('stat-tag-sub').textContent = topTag ? `used ${topTag[1]}x` : 'today';

  // Progress ring
  const pct = Math.round((filled / SLOTS.length) * 100);
  document.getElementById('ring-pct').textContent = pct + '%';
  const circumference = 2 * Math.PI * 18; // r=18
  const offset = circumference - (pct / 100) * circumference;
  document.getElementById('progress-ring').style.strokeDashoffset = offset;
}

// ── DATE NAVIGATION ───────────────────────────────────────────────────────
function loadDay(dateStr) {
  currentDate = dateStr;
  dayData = loadData(dateStr);

  document.getElementById('date-picker').value = dateStr;
  document.getElementById('date-label').textContent = fmtDate(dateStr);
  document.getElementById('day-badge').textContent = dayOfWeek(dateStr);

  renderSlots();
  updateStats();
}

function changeDay(delta) {
  const d = new Date(currentDate + 'T00:00:00');
  d.setDate(d.getDate() + delta);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  loadDay(`${y}-${m}-${day}`);
}

// ── SUMMARY MODAL ─────────────────────────────────────────────────────────
function showSummary() {
  const entries = SLOTS.map(s => ({ ...s, entry: dayData[s.id] || { text: '', tags: [] } }))
    .filter(x => x.entry.text.trim() || x.entry.tags.length > 0);

  const modalBody = document.getElementById('modal-body');
  document.getElementById('modal-title').textContent = '📋 ' + fmtDate(currentDate);

  if (entries.length === 0) {
    modalBody.innerHTML = '<p class="modal-empty">No entries logged for this day yet.</p>';
  } else {
    modalBody.innerHTML = entries.map(x => `
      <div class="modal-entry">
        <div class="modal-entry-time">${x.time}</div>
        ${x.entry.text ? `<div class="modal-entry-text">${x.entry.text}</div>` : ''}
        ${x.entry.tags.length ? `<div class="modal-entry-tags">${x.entry.tags.map(t => `<span class="modal-tag">${t}</span>`).join('')}</div>` : ''}
      </div>
    `).join('');
  }

  document.getElementById('modal-overlay').classList.add('open');
}

function closeModal() {
  document.getElementById('modal-overlay').classList.remove('open');
}

// ── COPY REPORT ───────────────────────────────────────────────────────────
function copyReport() {
  const lines = [
    `📋 Daily Work Log`,
    `📅 ${fmtDate(currentDate)}`,
    `👤 Web Developer Trainer`,
    `${'─'.repeat(40)}`,
  ];

  SLOTS.forEach(slot => {
    const entry = dayData[slot.id] || { text: '', tags: [] };
    const hasEntry = entry.text.trim() || entry.tags.length > 0;
    lines.push('');
    lines.push(`⏰ ${slot.time}`);
    if (entry.tags.length) lines.push(`   🏷 Tags: ${entry.tags.join(', ')}`);
    if (entry.text.trim()) lines.push(`   📝 ${entry.text.trim()}`);
    if (!hasEntry) lines.push(`   ─ (not logged)`);
  });

  lines.push('');
  lines.push('─'.repeat(40));
  const filled = SLOTS.filter(s => dayData[s.id] && (dayData[s.id].text || dayData[s.id].tags.length)).length;
  lines.push(`✅ ${filled} of ${SLOTS.length} slots filled`);

  navigator.clipboard.writeText(lines.join('\n'))
    .then(() => showToast('📋 Report copied to clipboard!'))
    .catch(() => showToast('⚠️ Could not copy. Try again.'));
}

// ── CLEAR DAY ─────────────────────────────────────────────────────────────
function clearDay() {
  if (!confirm('Clear all entries for ' + fmtDate(currentDate) + '?')) return;
  dayData = {};
  saveData();
  renderSlots();
  updateStats();
  showToast('🗑 Day cleared');
}

// ── INIT ──────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function () {
  // Date navigation
  document.getElementById('prev-day').addEventListener('click', () => changeDay(-1));
  document.getElementById('next-day').addEventListener('click', () => changeDay(1));
  document.getElementById('today-btn').addEventListener('click', () => loadDay(todayStr()));
  document.getElementById('date-picker').addEventListener('change', function () {
    if (this.value) loadDay(this.value);
  });

  // Action bar
  document.getElementById('clear-btn').addEventListener('click', clearDay);
  document.getElementById('summary-btn').addEventListener('click', showSummary);
  document.getElementById('copy-btn').addEventListener('click', copyReport);

  // Modal close
  document.getElementById('modal-close').addEventListener('click', closeModal);
  document.getElementById('modal-overlay').addEventListener('click', function (e) {
    if (e.target === this) closeModal();
  });

  // Load today
  loadDay(todayStr());
});
